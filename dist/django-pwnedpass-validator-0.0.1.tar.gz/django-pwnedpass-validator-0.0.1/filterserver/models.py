from django.db import models


class RemoteRequest(models.Model):
    ...

